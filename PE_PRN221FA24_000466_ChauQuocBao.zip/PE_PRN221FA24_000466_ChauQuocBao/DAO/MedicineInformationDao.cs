﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class MedicineInformationDao
    {
        private static MedicineInformationDao instance;
        public static MedicineInformationDao Instance
        {
            get
            {
                if (instance == null)
                    instance = new MedicineInformationDao();
                return instance;
            }
        }
        private Fall24PharmaceuticalDBContext _context;
        public MedicineInformationDao()
        {
            _context = new Fall24PharmaceuticalDBContext();
        }
        public MedicineInformation GetMedicineInformation(string id) => _context.MedicineInformations.FirstOrDefault(x => x.MedicineId == id);
        public List<MedicineInformation> GetMedicineInformations() => _context.MedicineInformations.ToList(); //_context.CandidateProfiles.Include(x => x.JobPosting).ToList();
        public void AddMedicineInformation(MedicineInformation medicineInformation)
        {
            _context.MedicineInformations.Add(medicineInformation);
            _context.SaveChanges();
            _context.Entry(medicineInformation).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
        }
        public void UpdateMedicineInformation(MedicineInformation medicineInformation)
        {
            MedicineInformation old = GetMedicineInformation(medicineInformation.MedicineId);
            if (old != null)
            {
                _context.MedicineInformations.Update(medicineInformation);
                _context.SaveChanges();
                _context.Entry(medicineInformation).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            }
        }
        public void DeleteMedicineInformation(string id)
        {
            MedicineInformation medicineInformation = GetMedicineInformation(id);
            if (medicineInformation != null)
            {
                _context.MedicineInformations.Remove(medicineInformation);
                _context.SaveChanges();
                _context.Entry(medicineInformation).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            }
        }
    }
}
