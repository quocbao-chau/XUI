﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class StoreAccountDao
    {
        private static StoreAccountDao instance;
        private Fall24PharmaceuticalDBContext _context;
        public StoreAccountDao()
        {
            if (_context == null)
            {
                _context = new Fall24PharmaceuticalDBContext();
            }
        }
        public static StoreAccountDao Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new StoreAccountDao();
                }
                return instance;
            }
        }

        public StoreAccount? GetStoreAccount(string email, string password) => _context.StoreAccounts.FirstOrDefault(x => x.EmailAddress == email && x.StoreAccountPassword == password);
    }
}
