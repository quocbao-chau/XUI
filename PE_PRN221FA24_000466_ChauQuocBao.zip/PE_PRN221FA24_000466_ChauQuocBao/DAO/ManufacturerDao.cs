﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class ManufacturerDao
    {
        private static ManufacturerDao instance;
        private Fall24PharmaceuticalDBContext _context;
        public ManufacturerDao()
        {
            if (_context == null)
            {
                _context = new Fall24PharmaceuticalDBContext();
            }
        }
        public static ManufacturerDao Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ManufacturerDao();
                }
                return instance;
            }
        }

        public Manufacturer? GetManufacturer(string id) => _context.Manufacturers.FirstOrDefault(x => x.ManufacturerId == id);
        public List<Manufacturer> GetManufacturers() => _context.Manufacturers.ToList();
    }
}
