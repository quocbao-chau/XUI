﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Repos
{
    public interface IStoreAccountRepo
    {
        public StoreAccount? GetStoreAccount(string email, string password);
    }
}
