﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repos
{
    public interface IMedicineInformationRepo
    {
        public MedicineInformation? GetMedicineInformation(string id);
        public void AddMedicineInformation(MedicineInformation medicineInformation);
        public void UpdateMedicineInformation(MedicineInformation medicineInformation);
        public void DeleteMedicineInformation(string id);
        public List<MedicineInformation> GetMedicineInformations();
    }
}
