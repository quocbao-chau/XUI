﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repos
{
    public interface IManufacturerRepo
    {
        public Manufacturer? GetManufacturer(string id);
        public List<Manufacturer> GetManufacturer();
    }
}
