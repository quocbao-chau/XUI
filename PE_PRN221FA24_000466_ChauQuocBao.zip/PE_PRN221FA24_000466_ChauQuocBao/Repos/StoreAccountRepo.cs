﻿using BOs;
using DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Repos
{
    public class StoreAccountRepo : IStoreAccountRepo
    {
        public StoreAccount? GetStoreAccount(string email, string password) => StoreAccountDao.Instance.GetStoreAccount(email, password);
    }
}
