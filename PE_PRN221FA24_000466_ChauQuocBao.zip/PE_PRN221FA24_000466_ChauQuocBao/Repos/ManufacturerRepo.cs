﻿using BOs;
using DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repos
{
    public class ManufacturerRepo : IManufacturerRepo
    {
        public Manufacturer? GetManufacturer(string id) => ManufacturerDao.Instance.GetManufacturer(id);

        public List<Manufacturer> GetManufacturer()
        {
            throw new NotImplementedException();
        }

        public List<Manufacturer> GetManufacturers() => ManufacturerDao.Instance.GetManufacturers();
    }
}
