﻿using BOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repos
{
    public class MedicineInformationRepo : IMedicineInformationRepo
    {
        public void AddMedicineInformation(MedicineInformation medicineInformation) => DAO.MedicineInformationDao.Instance.AddMedicineInformation(medicineInformation);

        public void DeleteMedicineInformation(string id) => DAO.MedicineInformationDao.Instance.DeleteMedicineInformation(id);

        public MedicineInformation? GetMedicineInformation(string id) => DAO.MedicineInformationDao.Instance.GetMedicineInformation(id);

        public List<MedicineInformation> GetMedicineInformations() => DAO.MedicineInformationDao.Instance.GetMedicineInformations();

        public void UpdateMedicineInformation(MedicineInformation medicineInformation) => DAO.MedicineInformationDao.Instance.UpdateMedicineInformation(medicineInformation);
    }
}
