using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PharmaceuticalManagement_ChauQuocBao.Pages
{
    public class PermissionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
