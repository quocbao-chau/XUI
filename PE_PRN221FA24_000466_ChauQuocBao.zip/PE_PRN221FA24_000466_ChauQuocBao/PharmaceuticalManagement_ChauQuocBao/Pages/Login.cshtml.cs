using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Repos;

namespace PharmaceuticalManagement_ChauQuocBao.Pages
{
    public class LoginModel : PageModel
    {
        private readonly IStoreAccountRepo _storeaccountRepo;
        public LoginModel(IStoreAccountRepo storeaccountRepo)
        {
            _storeaccountRepo = storeaccountRepo;
        }
        public string ErrorMessage { get; set; }
        public void OnGet()
        {
        }
        public void OnPost()
        {
            var email = Request.Form["txtEmail"];
            var password = Request.Form["txtPassword"];
            var account = _storeaccountRepo.GetStoreAccount(email, password);
            if (account == null || account.Role == 1 || account.Role == 4)
                ErrorMessage = "You do not have permission to do this function!";
            else
            {
                HttpContext.Session.SetString("RoleID", account.Role.ToString());
                Response.Redirect("/MedicineInformationPage");
            }
        }
    }
}
