﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BOs;
using DAO;
using Repos;

namespace PharmaceuticalManagement_ChauQuocBao.Pages.MedicineInformationPage
{
    public class IndexModel : PageModel
    {
        private readonly IMedicineInformationRepo _medicineInformationRepo;
        private readonly IManufacturerRepo _manufacturerRepo;

        public IndexModel(IMedicineInformationRepo medicineInformationRepo, IManufacturerRepo manufacturerRepo)
        {
            _medicineInformationRepo = medicineInformationRepo;
            _manufacturerRepo = manufacturerRepo;
        }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 3;
        public int TotalPages { get; set; } = 1;

        public IList<MedicineInformation> MedicineInformation { get;set; } = default!;

        public async Task OnGetAsync(int pageNumber = 1)
        {
            PageNumber = pageNumber;
            var medicineInformations = _medicineInformationRepo.GetMedicineInformations();
            var totalItems = medicineInformations.Count;
            TotalPages = (int)Math.Ceiling(totalItems / (double)PageSize);
            medicineInformations = medicineInformations.Skip((PageNumber - 1) * PageSize).Take(PageSize).ToList();

            medicineInformations.ForEach(medicineInformation =>
            {
                medicineInformation.Manufacturer = _manufacturerRepo.GetManufacturer(medicineInformation.ManufacturerId);
            });
            MedicineInformation = medicineInformations;
        }
    }
}
