﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using BOs;
using DAO;

namespace PharmaceuticalManagement_ChauQuocBao.Pages.MedicineInformationPage
{
    public class CreateModel : PageModel
    {
        private readonly DAO.Fall24PharmaceuticalDBContext _context;

        public CreateModel(DAO.Fall24PharmaceuticalDBContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["ManufacturerId"] = new SelectList(_context.Manufacturers, "ManufacturerId", "ManufacturerId");
            return Page();
        }

        [BindProperty]
        public MedicineInformation MedicineInformation { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.MedicineInformations == null || MedicineInformation == null)
            {
                return Page();
            }

            _context.MedicineInformations.Add(MedicineInformation);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
