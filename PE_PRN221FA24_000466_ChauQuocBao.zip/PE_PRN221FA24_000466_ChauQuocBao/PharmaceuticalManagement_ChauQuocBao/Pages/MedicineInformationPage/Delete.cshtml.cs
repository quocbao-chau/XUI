﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BOs;
using DAO;
using Repos;

namespace PharmaceuticalManagement_ChauQuocBao.Pages.MedicineInformationPage
{
    public class DeleteModel : PageModel
    {
        private readonly IMedicineInformationRepo _medicineInformationRepo;
        private readonly IManufacturerRepo _manufacturerRepo;

        public DeleteModel(IMedicineInformationRepo medicineInformationRepo, IManufacturerRepo manufacturerRepo)
        {
            _medicineInformationRepo = medicineInformationRepo;
            _manufacturerRepo = manufacturerRepo;
        }

        [BindProperty]
      public MedicineInformation MedicineInformation { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicineinformation = _medicineInformationRepo.GetMedicineInformation(id);

            if (medicineinformation == null)
            {
                return NotFound();
            }
            else 
            {
                medicineinformation.Manufacturer = _manufacturerRepo.GetManufacturer(medicineinformation.ManufacturerId);
                MedicineInformation = medicineinformation;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var medicineinformation = _medicineInformationRepo.GetMedicineInformation(id);

            if (medicineinformation != null)
            {
                MedicineInformation = medicineinformation;
                _medicineInformationRepo.DeleteMedicineInformation(MedicineInformation.MedicineId);
            }

            return RedirectToPage("./Index");
        }
    }
}
